# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['indicadores_siops']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.4.3,<4.0.0',
 'pandas>=1.3.3,<2.0.0',
 'peewee>=3.14.4,<4.0.0',
 'seaborn>=0.11.2,<0.12.0']

setup_kwargs = {
    'name': 'indicadores-siops',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Luiz Alexandre',
    'author_email': 'luizalexandre21@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/LuizAlexandre21/Indicadores_siops',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
